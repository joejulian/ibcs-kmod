#ifndef _ABI_UTIL_PROC_H
#define _ABI_UTIL_PROC_H

//#ident "%W% %G%"

extern int abi_proc_init(void);
extern void abi_proc_exit(void);

#endif /* _ABI_UTIL_PROC_H */
