#ifndef _ABI_UTIL_SHINOMAP_H
#define _ABI_UTIL_SHINOMAP_H

//#ident "%W% %G%"

extern int abi_shinomap_init(void);
extern void abi_shinomap_exit(void);

extern int short_inode_mapping;

#endif /* _ABI_UTIL_SHINOMAP_H */

